
from aiogram.types import Message, CallbackQuery, ReplyKeyboardMarkup
from loader import dp
from main import ok
from data.config import PREFIX
import requests
from aiogram import  types



@dp.message_handler(commands=['bin'], commands_prefix=PREFIX)
async def cdgh(message: types.Message):
  try:


    cc = message.text[len('/bin '):]
    splitter = cc.split('|')
    BIN = splitter[0]
    BIN = cc[:6]
    fbin = cc[:6]
    session = requests.session()
    bin = session.get(f"https://lookup.binlist.net/{fbin}").json()
    try:
      brand = bin["scheme"].upper()
    except:
      brand = "N/A"
    try:
      type = bin["type"].upper()
    except:
      type = "N/A"
    try:
      level = bin["brand"].upper()
    except:
      level = "N/A"
    try:
      bank_data = bin["bank"]
    except:
      bank_data = "N/A"
    try:
      bank = bank_data["name"].upper()
    except:
      bank = "N/A"
    try:
      country_data = bin["country"]
    except:
      country_data = "N/A"
    try:
      country = country_data["name"].upper()
    except:
      country = "N/A"
    try:
      flag = country_data["emoji"]
    except:
      flag = "N/A"
    try:
      currency = country_data["currency"].upper()
    except:
      currency = "N/A"


    INFO = f'''
<b>Valid {BIN}</b> ✅

<b> ————Bin Details———— </b>

Brand -» <b>{brand}</b>
Type -» <b>{type} {level}</b>
Bank  -»<b>{bank}</b>
Country -»<b>{country} {flag} {currency}</b>

Checked by -» <a href="tg://user?id={message.from_user.id}">{message.from_user.first_name}</a> <b>[{ok(message.from_user.id)}]</b>
  '''
    await message.reply(INFO)
  except:
    return await message.reply("❌  Invalid Bin ❌ ")


