from aiogram.types.message import ContentType
from aiogram import types
import random
from database import create_user_test
from gtts import gTTS
from googletrans import Translator
import os
from aiogram.types import InputFile
from loader import dp
from aiogram import Bot
from data.config import BOT_TOKEN

bot = Bot(BOT_TOKEN, parse_mode='HTML')
PREFIX = "!/."


@dp.message_handler(commands=['tr'], commands_prefix=PREFIX)
async def cdgh(message: types.Message):
  try:
    inp = message.text[len('/tr '):]
    rd3_lang = inp[0:2]

    if message.reply_to_message:
      language = message.reply_to_message.text

    else:
      language = inp[3:]

    translator = Translator()
    to_lang = rd3_lang
    text_to_translate = translator.translate(language, dest=to_lang)
    text = text_to_translate.text
    await message.reply(text)

  except:
    await message.reply(
      'Invalid Format example: /tr (language code) text to translate \n to see language code type /code'
    )


@dp.message_handler(commands=['voice'], commands_prefix=PREFIX)
async def cdgfgh(message: types.Message):
  try:
    inp = message.text[len('/voice '):]
    rd3_lang = inp[0:2]

    if message.reply_to_message:
      language = message.reply_to_message.text

    else:
      language = inp[3:]

    translator = Translator()
    to_lang = rd3_lang
    text_to_translate = translator.translate(language, dest=to_lang)
    text = text_to_translate.text
    speak = gTTS(text=text, lang=to_lang, slow=False)
    name = random.randint(1, 2000)
    title = f"voice{name}.mp3"
    speak.save(title)
    await message.reply_voice(InputFile(title))
    os.remove(title)
  except:
    await message.reply(
      'Invalid Format example: /voice (language code) text to translate \n to see language code type /code'
    )


@dp.message_handler(commands=['code'], commands_prefix=PREFIX)
async def cdgh(message: types.Message):

  text = """
    
Language Name	Language Code
Afrikaans af
Albanian sq
Arabic ar
Azerbaijani az
Basque eu
Belarusian be
Bengali bn
Bulgarian bg
Catalan ca
Chinese Simplified zh-CN
Chinese Traditional zh-TW
Croatian hr
Czech cs
Danish da
Dutch nl
English en
Esperanto eo
Estonian et
Filipino tl
Finnish fi
French fr
Galician gl
Georgian ka
German de
Greek el
Gujarati gu
Haitian Creole ht
Hebrew iw
Hindi hi
Hungarian hu
Icelandic is
Indonesian id
Irish ga
Italian it
Japanese ja
Kannada kn
Korean ko
Language Name Language Code
Latin la
Latvian lv
Lithuanian lt
Macedonian mk
Malay ms
Maltese mt
Norwegian no
Persian fa
Polish pl
Portuguese pt
Romanian ro
Russian ru
Serbian sr
Slovak sk
Slovenian sl
Spanish es
Swahili sw
Swedish sv
Tamil ta
Telugu te
Thai th
Turkish tr
Ukrainian uk
Urdu ur
Vietnamese vi
Welsh cy
Yiddish yi"""

  await message.reply(text)


PAYMENTS_TOKEN = "5845424744:AAHbwrqyBSODhkuUUzxKfW096AKQgEAOmeY"
item_url = "https://images.indianexpress.com/2022/06/Telegram-premium-subscription.jpg"
# prices
PRICE = types.LabeledPrice(label="Bot Premium",
                           amount=10 * 100)  # amount need be in cents!


@dp.message_handler(commands=['love'], commands_prefix=PREFIX)
async def buy(message: types.Message):

  await bot.send_invoice(
    message.chat.id,
    title="Bot Premium",
    description="lucy Premium Bot",
    provider_token=PAYMENTS_TOKEN,
    currency="rub",  # You can use USD (dol 
    photo_url=item_url,
    photo_width=416,
    photo_height=234,
    photo_size=416,
    is_flexible=False,
    prices=[PRICE],
    start_parameter="one-month-subcription",
    payload="test-invoice-payload")


@dp.pre_checkout_query_handler(lambda query: True)
async def pre_checkout_query(pre_checkout_q: types.PreCheckoutQuery):
  await bot.answer_pre_checkout_query(pre_checkout_q.id, ok=True)


@dp.message_handler(content_types=ContentType.SUCCESSFUL_PAYMENT)
async def successful_payment(message: types.Message):

  nm = f'''<b>✅<a href="tg://user?id={message.from_user.id}">{message.from_user.full_name}</a> Thankyou For taking subscription in Our Bot.</b>'''

  text = f"<b>Payment for the amount </b>{message.successful_payment.total_amount // 100} {message.successful_payment.currency}\n{nm}"
  await bot.send_message(message.chat.id, text)
  userid = message.from_user.id
  create_user_test(userid)

  username = message.from_user.username
  try:

    await bot.send_message(chat_id="-1001769748267",
                           text=f"@{username} Subscribed to our bot \n {text}")

  except Exception as e:
    print(e)
