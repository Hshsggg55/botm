from aiogram import *
from data.config import OWNER_NAME, OWNER_LINK, GROUP, CHANNEL
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from main import ok
from loader import dp

PREFIX = "!/."

#===========================================================================handler ========================================================================


  
@dp.callback_query_handler(text=["free", "paid", "close", "other", "back"])
async def process_cart(call: types.CallbackQuery):

  original = call.message.reply_to_message.from_user.id
  cc = call.get_current()
  id = cc.from_user.id
  if id == original:

    if call.data == "free":
      button1 = InlineKeyboardButton(text="Mass gates", callback_data="paid")
      button3 = InlineKeyboardButton(text="🔙", callback_data="back")
      button4 = InlineKeyboardButton(text="🔚", callback_data="close")

      keyboard_inline = InlineKeyboardMarkup().add(button1).add(
        button3, button4)

      await call.message.edit_text(f"""
<b>
all gates are made with love and hard work :) by {OWNER_NAME}

/ch stripe auth 1$

/chk stripe  0$

/ay adyen 16$

/sh Shopify 6$

</b>
[~] Adding more...

<b> Bot made by: <a href='{OWNER_LINK}'> {OWNER_NAME} </a> </b>""",
                                   reply_markup=keyboard_inline,
                                   disable_web_page_preview=True)

    elif call.data == "paid":

      button1 = InlineKeyboardButton(text="Normal gates", callback_data="free")
      button3 = InlineKeyboardButton(text="🔙", callback_data="back")
      button4 = InlineKeyboardButton(text="🔚", callback_data="close")
      keyboard_inline = InlineKeyboardMarkup().add(button1).add(
        button3, button4)

      await call.message.edit_text(f"""<b>

/ssk mass stripe 0.5$

[~] Adding more...
</b>
<b> Bot made by: <a href='{OWNER_LINK}'> {OWNER_NAME} </a> </b>""",
                                   reply_markup=keyboard_inline,
                                   disable_web_page_preview=True)

    elif call.data == "close":
      await call.message.edit_text("Enjoy Baby 🧸.")

    elif call.data == "back":
      button1 = InlineKeyboardButton(text="Normal gates", callback_data="free")
      button2 = InlineKeyboardButton(text="Mass gates", callback_data="paid")
      button3 = InlineKeyboardButton(text="🔙", callback_data="back2")
      button4 = InlineKeyboardButton(text="🔚", callback_data="close")
      keyboard_inline = InlineKeyboardMarkup().add(button1).add(button2).add(
        button3, button4)

      await call.message.edit_text(f"""
        <b>
Hello, it seems to me that you are interested in my commands, you can explore by pressing any of the buttons
<b>User type = {call.message.reply_to_message.from_user.username}</b> ({ok(call.message.reply_to_message.from_user.id)})
Bot made by: <a href='{OWNER_LINK}'> {OWNER_NAME} </a> </b>""",
                                   reply_markup=keyboard_inline,
                                   disable_web_page_preview=True)

    elif call.data == "other":

      button2 = InlineKeyboardButton(text="🔙", callback_data="back2")
      button3 = InlineKeyboardButton(text="🔚", callback_data="close")
      keyboard_inline = InlineKeyboardMarkup().add(button2, button3)

      await call.message.edit_text(f"""
<b>
/status to check group status
/check check your own id
/admins

/clean (text to extract cc)
/bin xxxxxx  to check bin 
/fake or /us generat fake data
/ipgen (amount) generate ip list
/gen cc gen
/hma HMA key checker
/phone (number) 
/fix (headers) headers editor
/ip (check ip risk score)
/sk sk_live_xxx to check sk keys (with balance)
/buy to buy bot 
/inf to check group id 

[proxy cmds]

/http
/socks4
/socks5

[translator]
/tr (language_code) text
/voice (language_code) text
/code 

[admin cmds]

/adduser
/deluser
/addadmin
/deladmin
/approve
/revoke

</b>
<b> Bot made by: <a href='{OWNER_LINK}'> {OWNER_NAME} </a> </b>""",
                                   reply_markup=keyboard_inline,
                                   disable_web_page_preview=True)

  else:

    return await call.answer(
      "❌ Access denied, only the user who used the command can navigate the buttons. ❗️",
      show_alert=True)
