BOT_TOKEN = '5805427581:AAFsAshpl9VObEOhgUJGZD2aJqfbROQN4cY'

PREFIX = "!/."

ANTISPAM = int(60)

OWNER = ["5676623563"]

APP_ID = "28361386"

API_HASH = "7c824af57f60a872f12bb0108398b566"

SESSION = "1BJWap1sBuzT830JePSMapsfyGaoU35IF-_9XcN5h808UEwTGObbP03l0vTk45dhi3pNG2L_IhFEgqnkv8sGopeebar-8GvjpnXLVvx80YvBLxTvgEaA7Q6nbUwkVtzVd1NcKH4k2ehoXr1NPxvNzGhQ2uNOCVSpBYCRjVbEgL0dERngEseyzGrcSxs8CD9ne1fBQV4GyPts0nQ1JpDqGfaSQWTEDq8H1_ksjZ1X_ACy0amlWFVyfhltpOeRe5BLjPGrjyTh8bmy4vABelj0wB-7Bd_xAXhtQYlPGhevMl1ebGao-wCTzXWCjIkLJebKlynBAqLw21urKfLHa4qRJXqiNBZ_NbH0="

OWNERID = int(5676623563)

OWNER_NAME = "@Z_O_K_S_H_7"

CHANNEL = "https://t.me/drugs_h_c"

GROUP = "https://t.me/drugs_h_c"

OWNER_LINK = "https://t.me/Z_O_K_S_H_7"

from database import check_user, check_admin


def ok(id):

  if check_admin(id) == True:
    user = "5719360455"
    return user

  elif check_user(id) == True:
    user = "https://t.me/Z_O_K_S_H_7"
    return user

  elif check_user(id) == False or check_admin(id) == False:
    user = "https://t.me/Z_O_K_S_H_7"
    return user

  else:
    user = "https://t.me/Z_O_K_S_H_7"
    return user
