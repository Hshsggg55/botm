import os
import requests
import handlers
from aiogram import executor, types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from loader import dp, bot
from data.config import *
from database import *
import time
import logging
import asyncio
logging.basicConfig(level=logging.INFO)

# BOT INFO



@dp.message_handler(commands=['admins'], commands_prefix=PREFIX)
async def helpstr(message: types.Message):

  group = message.chat.id
  ug = message.chat.type
  if "supergroup" in ug or "group" in ug:
    members = await bot.get_chat_administrators(group)
    members2 = ""
    for x in members:
      if "creator" in {x.status}:
        members2 += (
          f"<a href='tg://user?id={x.user.id}'>{x.user.username}</a>--><b>My God :)</b>\n"
        )
      else:

        members2 += (
          f"<a href='tg://user?id={x.user.id}'>{x.user.username}</a>\n")
    await message.reply(members2)
  else:
    await message.reply("""Cannot Use this command in Private Chat""",
                        disable_web_page_preview=True)


@dp.message_handler(commands=['id'], commands_prefix=PREFIX)
async def helpstr(message: types.Message):
  user_id = message.text

  if len(user_id) == 3:
    query = message.from_user.id

  else:
    query = message.text[len('/id '):]

  try:

    km = await bot.get_chat(query)
    q1 = km.first_name
    q2 = km.last_name
    if q2 == None:
      q2 = ""
    q3 = km.bio
    q4 = km.username
    q5 = km.id
    await message.reply(f"""<b>
ID : <code>{q5}</code>
Name : <i>{q1} {q2}</i>
Bio : <i>{q3}</i>
UserName: <i>{q4}</i> </b>
""")

  except Exception as e:
    await message.reply(e)


@dp.message_handler(
  commands=['start', 'help', 'cmd', 'cmds', 'command', 'commands'],
  commands_prefix=PREFIX)
async def helpstr(message: types.Message):
  button1 = InlineKeyboardButton(text="My Account", callback_data="mee")
  button2 = InlineKeyboardButton(text="Gateway", callback_data="back")
  button3 = InlineKeyboardButton(text="Tools", callback_data="other")
  button4 = InlineKeyboardButton(text="Channel", url=f"{CHANNEL}")
  button5 = InlineKeyboardButton(text="Group", url=f"{GROUP}")
  button6 = InlineKeyboardButton(text="Buy Here", callback_data="buy1")
  button7 = InlineKeyboardButton(text="Close", callback_data="lose")

  keyboard_inline = InlineKeyboardMarkup().add(button1).add(
    button2, button3).add(button6).add(button4, button5).add(button7)
  text = f"<b> Hii {message.from_user.mention} Your User id is <code> {message.from_user.id}</code></b>"
  await message.reply(text,
                      reply_markup=keyboard_inline,
                      disable_web_page_preview=True)


# ===========================================================================handler ========================================================================


@dp.callback_query_handler(text=["mee", "back2", "lose"])
async def process_cart(call: types.CallbackQuery):

  original = call.message.reply_to_message.from_user.id
  cc = call.get_current()
  id = cc.from_user.id
  if id == original:

    if call.data == "mee":

      tec = f"""<b>
Your Account Info:
━━━━━━━━━
ID: <code>{call.message.reply_to_message.from_user.id}</code>
Name: {call.message.reply_to_message.from_user.first_name}
Username: {call.message.reply_to_message.from_user.mention}
Plan: {ok(call.message.reply_to_message.from_user.id)} 
━━━━━━━━━
<i>Expire on </i> = <b>{(fetch_expiry_date(id))}</b>
<i>Days_left </i> = <b>{check_expiry_days(id)}</b>
</b>
"""

      button5 = InlineKeyboardButton(text="🔚", callback_data="back2")

      keyboard_inline = InlineKeyboardMarkup().add(button5)

      return await call.message.edit_text(tec,
                                          reply_markup=keyboard_inline,
                                          disable_web_page_preview=True)

    if call.data == "back2":
      button1 = InlineKeyboardButton(text="My Account", callback_data="mee")
      button2 = InlineKeyboardButton(text="Gateway", callback_data="back")
      button3 = InlineKeyboardButton(text="Tools", callback_data="other")
      button4 = InlineKeyboardButton(text="Channel", url=f"{CHANNEL}")
      button5 = InlineKeyboardButton(text="Group", url=f"{GROUP}")
      button6 = InlineKeyboardButton(text="Buy Here", callback_data="buy1")
      button7 = InlineKeyboardButton(text="Close", callback_data="lose")

      keyboard_inline = InlineKeyboardMarkup().add(button1).add(
        button2, button3).add(button6).add(button4, button5).add(button7)
      text = f"<b> Hii {call.message.reply_to_message.from_user.mention} Your User id is <code> {call.message.reply_to_message.from_user.id}</code> </b>"
      await call.message.edit_text(text,
                                   reply_markup=keyboard_inline,
                                   disable_web_page_preview=True)

    if call.data == "lose":

      await call.message.edit_text("Enjoy Baby 🧸.")

  else:

    return await call.answer(
      "❌ Access denied, only the user who used the command can navigate the buttons. ❗️",
      show_alert=True)


@dp.callback_query_handler(
  text=["buy1", "close1", "1_MONTH1", "1_WEEK1", "1_DAY1"])
async def process_cart(call: types.CallbackQuery):

  original = call.message.reply_to_message.from_user.id
  cc = call.get_current()
  id = cc.from_user.id
  if id == original:

    if call.data == "buy1":
      button1 = InlineKeyboardButton(text="30 Days", callback_data="1_MONTH1")
      button2 = InlineKeyboardButton(text="15 Days", callback_data="1_WEEK1")
      button3 = InlineKeyboardButton(text="7 Days", callback_data="1_DAY1")
      button4 = InlineKeyboardButton(text="🔙", callback_data="back2")
      button5 = InlineKeyboardButton(text="🔚", callback_data="lose")

      keyboard_inline = InlineKeyboardMarkup().add(button1).add(button2).add(
        button3).add(button4, button5)

      return await call.message.edit_text("""<b>
━━━━━━━━━━━━━
: Premium Membership Prices
━━━━━━━━━━━━━
[+] 7 Days > 3$ 
[+] 14 Days > 6$
[+] 30 Days >  12$
━━━━━━━━━━━━━
[+] Payment Method ( 

Crypto:[BTC,LTC,ETH,USDT] ;
paypal ;
Payoneer ;
India:[Upi,Bank Transfer] ;
Other:[btc(via any app)] ;

)
━━━━━━━━━━━━━
By: @m3m4452

⚠️ I Do Not Accept  Payment From Friends :) ( I Am Your Friend ). </b>""",
                                          reply_markup=keyboard_inline,
                                          disable_web_page_preview=True)

    elif call.data == "close1":
      await call.message.edit_text("Enjoy Baby 🧸.")

    elif call.data == "1_MONTH1":
      button1 = InlineKeyboardButton(text="🔚", callback_data="lose")
      button2 = InlineKeyboardButton(text="🔙", callback_data="buy1")
      keyboard_inline = InlineKeyboardMarkup().add(button2, button1)
      text = f"""
Payment Method: Crypto
<b>Payable: 12.00 USD | 12$  </b>

Payment details:
<b>paying 12$ to {OWNER_NAME} for lucy checker  </b>

Crypto payment.

<b>USDT TRC20 (TRON NETWORK) - </b>
<code>TWnCxFdnhdpQ3RJ4kwVn1MMiTEvn9hRGHB</code>


<b>BTC - <code>31yV4ump1ykB6MTNAiFhJioXMU3yaZyp24</code></b>

want any other crypto contact {OWNER_NAME}
__________________________
You pay to an individual.
After payment Take SS and Send it to {OWNER_NAME}

<b>⚠️NOTE⚠️ date,time of payment and amount  must be clear in SS </b>
    """

      await call.message.edit_text(text, reply_markup=keyboard_inline)

    elif call.data == "1_WEEK1":
      button1 = InlineKeyboardButton(text="🔚", callback_data="lose")
      button2 = InlineKeyboardButton(text="🔙", callback_data="buy1")
      keyboard_inline = InlineKeyboardMarkup().add(button2, button1)

      text = f"""
Payment Method: Crypto
<b>Payable: 6.00 USD | 6$  </b>

Payment details:
<b>paying 6$ to {OWNER_NAME} for lucy checker  </b>

Crypto payment.

<b>USDT TRC20 (TRON NETWORK) - </b>
<code>TWnCxFdnhdpQ3RJ4kwVn1MMiTEvn9hRGHB</code>


<b>BTC - <code>31yV4ump1ykB6MTNAiFhJioXMU3yaZyp24</code></b>

want any other crypto contact {OWNER_NAME}
__________________________
You pay to an individual.
After payment Take SS and Send it to {OWNER_NAME}

<b>⚠️NOTE⚠️ date,time of payment and amount  must be clear in SS </b>"""

      await call.message.edit_text(text, reply_markup=keyboard_inline)

    elif call.data == "1_DAY1":
      button1 = InlineKeyboardButton(text="🔚", callback_data="lose")
      button2 = InlineKeyboardButton(text="🔙", callback_data="buy1")
      keyboard_inline = InlineKeyboardMarkup().add(button2, button1)

      text = f"""
Payment Method: Crypto
<b>Payable: 3.00 USD | 3$  </b>

Payment details:
<b>paying 3$ to {OWNER_NAME} for lucy checker  </b>

Crypto payment.

<b>USDT TRC20 (TRON NETWORK) - </b>
<code>TWnCxFdnhdpQ3RJ4kwVn1MMiTEvn9hRGHB</code>


<b>BTC - <code>31yV4ump1ykB6MTNAiFhJioXMU3yaZyp24</code></b>

want any other crypto contact {OWNER_NAME}
__________________________
You pay to an individual.
After payment Take SS and Send it to {OWNER_NAME}

<b>⚠️NOTE⚠️ date,time of payment and amount  must be clear in SS </b>"""

      await call.message.edit_text(text, reply_markup=keyboard_inline)

  else:

    return await call.answer(
      "❌ Access denied, only the user who used the command can navigate the buttons. ❗️",
      show_alert=True)


# ------------------------------------------------------buy-------------------------------------
@dp.message_handler(commands=['plan', 'plans', 'buy'], commands_prefix=PREFIX)
async def infobbkc(message: types.Message):

  m = message.from_user.id
  kc = ok(m)
  if "OWNER" in kc:
    button1 = InlineKeyboardButton(text="🔚", callback_data="lose")
    keyboard_inline = InlineKeyboardMarkup().add(button1)
    return await message.reply('''<b>how can a owner buy his own bot :)</b>''',
                               reply_markup=keyboard_inline)
  elif "PAID" in kc:
    button1 = InlineKeyboardButton(text="🔚", callback_data="lose")
    keyboard_inline = InlineKeyboardMarkup().add(button1)
    return await message.reply(
      f'''<a href="tg://user?id={m}">{message.from_user.first_name}</a> no need to buy you are alredy a premium member''',
      reply_markup=keyboard_inline)
  else:

    button1 = InlineKeyboardButton(text="⚡️plans⚡️", callback_data="buy1")
    button2 = InlineKeyboardButton(text="🔚", callback_data="lose")

    keyboard_inline = InlineKeyboardMarkup().add(button1).add(button2)
    return await message.reply(
      """<b>click the below button to see my plans</b>""",
      reply_markup=keyboard_inline,
      disable_web_page_preview=True)


@dp.message_handler(commands=['http'], commands_prefix=PREFIX)
async def example_func(message: types.Message):

  import requests
  proxyrequest = requests.get(
    "https://api.proxyscrape.com?request=getproxies&proxytype=http")
  proxyrequest_format = proxyrequest.text.strip()
  proxyrequest_format = proxyrequest_format.replace("\r", "")
  list_proxies = list(proxyrequest_format.split("\n"))

  with open("http.txt", "w") as proxywrite:
    for proxy in list_proxies:
      proxywrite.write("%s\n" % proxy)

  oo = "http.txt"
  md = open(oo, "rb")
  await message.reply_document(document=md,
                               caption=f"""
<b>Success! Done ✅! </b>
""")
  os.remove(oo)


@dp.message_handler(commands=['Socks4'], commands_prefix=PREFIX)
async def example_func(message: types.Message):

  import requests
  proxyrequest = requests.get(
    "https://api.proxyscrape.com?request=getproxies&proxytype=socks4")
  proxyrequest_format = proxyrequest.text.strip()
  proxyrequest_format = proxyrequest_format.replace("\r", "")
  list_proxies = list(proxyrequest_format.split("\n"))

  with open("socks4.txt", "w") as proxywrite:
    for proxy in list_proxies:
      proxywrite.write("%s\n" % proxy)

  oo = "socks4.txt"
  md = open(oo, "rb")
  await message.reply_document(document=md,
                               caption=f"""
<b>Success! Done ✅! </b>
""")
  os.remove(oo)


@dp.message_handler(commands=['Socks5'], commands_prefix=PREFIX)
async def example_func(message: types.Message):

  import requests
  proxyrequest = requests.get(
    "https://api.proxyscrape.com?request=getproxies&proxytype=socks5")
  proxyrequest_format = proxyrequest.text.strip()
  proxyrequest_format = proxyrequest_format.replace("\r", "")
  list_proxies = list(proxyrequest_format.split("\n"))

  with open("socks5.txt", "w") as proxywrite:
    for proxy in list_proxies:
      proxywrite.write("%s\n" % proxy)

  oo = "socks5.txt"
  md = open(oo, "rb")
  await message.reply_document(document=md,
                               caption=f"""
<b>Success! Done ✅! </b>
""")
  os.remove(oo)


@dp.message_handler(commands=['inf'], commands_prefix=PREFIX)
async def example_func(message: types.Message):
  ug = message.chat.id
  name = message.chat.full_name
  await message.reply(f"{name}'s id <code>{ug}</code>")


# ====================================================================info====================================================================
# ------------------------------------------------------info-------------------------------------
@dp.message_handler(commands=['info', 'id', 'me'], commands_prefix=PREFIX)
async def info(message: types.Message):

  if message.reply_to_message:
    user_id = message.reply_to_message.from_user.id
    is_bot = message.reply_to_message.from_user.is_bot
    username = message.reply_to_message.from_user.username
    first = message.reply_to_message.from_user.first_name

  else:
    user_id = message.from_user.id
    is_bot = message.from_user.is_bot
    username = message.from_user.username
    first = message.from_user.first_name

  user_id = user_id

  if user_id == 5719360455:
    chcc = "OWNER"

  else:
    chcc = ok(user_id)

  await message.answer(f'''
 
<b>USER INFO</b>

<b>🆔 ID:</b> <code>{user_id}</code>
<b>👱 NAME:</b><a href="tg://user?id={user_id}">{first}</a>
<b>🌐 Username:</b> @{username}
<b>👀 User type = </b> [{chcc}]
<b>🤖 IS bot = </b> {is_bot}
''')


import time


@dp.message_handler(commands=['ping'], commands_prefix=PREFIX)
async def cdgh(message: types.Message):
  s = time.perf_counter()
  me = await message.reply("<b>Checking...</b>", disable_web_page_preview=True)
  e = time.perf_counter()
  try:
    await me.edit_text(f"<code>Ping: {(e-s)*1000:.2f} ms</code>")
  except Exception as e:
    print(e)


if __name__ == '__main__':

  executor.start_polling(dp, skip_updates=True)
